todo
user registration api with dynamo kinesis and lambda
integration tests
unit tests
tests for retunring exceptions, e.g http excpetion vs kinesis exception or dynamo exception (unit test for handler boilerplate)
local / remote debug switch
local debug with events
local debug windows?
boiler plate handler wrap with exception handling
common logging format
Jenkins 2 cd pipeline
serverless encrypted env vars
accompanying docs

General serverless guidelines
Keep package sizes as small as possible to minimize cold start times
